from distutils.core import setup, Extension

LDA_module = Extension('LDA_module',
                       sources = ['LDA_module.c'],
                       extra_objects = ['LDAhid.o'],
                       libraries = ['usb-1.0'])


setup(name = 'Vaunix LDA Python 3 support',
      version = '1.05',
      description = 'Python Package for Vaunix LDA attenuators',
      ext_modules = [LDA_module],

      url='http://www.vaunix.com',
      author='Howard Eglowstein for Vaunix, Inc.',
      author_email='howard@overpricedsoftware.com')
