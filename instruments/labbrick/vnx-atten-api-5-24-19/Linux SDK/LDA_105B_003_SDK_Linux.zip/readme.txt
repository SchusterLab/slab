Readme for Linux LDA library V1.05 May 9, 2019

This version of the Vaunix Linux LDA library has a number of changes from the earlier versions, see the change log for details.

It is based on libusb 1.0, and has been tested with both early versions of libusb (1.0.15 or earlier on Fedora FC19) as well as current versions (Ubuntu 18).
Due to the changes in libusb 1.0 over time you will need to manually configure the LDAhid.c code if you want to use the run time tracing feature. Versions of 
libusb 1.0 prior to 1.0.22 use the libusb_set_debug function to control the trace messages in libusb. Later versions use libusb_set_option. Uncomment the code
that is suitable for the version of libusb you are using, and set the related #defines in the LDAHid source.

If your system does not have the developer version of libusb 1.0 installed, install it prior to building the examples. For typical systems you can use:

sudo apt-get install libusb-1.0-0-dev

You can check for the location of the installed libusb.h file using the command:

sudo updatedb && locate libusb.h

Make sure that the path to libusb.h  is included in the gcc command line in the makefile

The makefile includes examples of some common gcc command lines used on various systems, including Ubuntu, Fedora, and the Raspberry Pi. You should 
adjust the command lines to be compatible with your system.

