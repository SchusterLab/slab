#include <Python.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
// A cheap hack here. The LDAhid.h file includes libusb.h but for
// the standalone C code we need to specifiy it differently. We define
// a symbol and the .H file uses it to decide which way to get it.
#define COMPILING_PYTHON_WRAPPER
#include "LDAhid.h"
#undef COMPILING_PYTHON_WRAPPER
//#include "LDAhidPy.h"
#define FALSE 0
#define TRUE !FALSE
#define VERBOSE 0
#define WRAPPERVERSION "1.05"

/* --------------------------- Version history ---------------------------
   2017-07-25   HME  Initial coding, version 0.1 using C library 1.02
   2017-12-11   RD   LDA version, based on LMS code
   2018-08-28   HME  Modified to use the libusb 1.0 C code and support
                     for multichannel devices
   2019-01-04   HME  Updated version numbers to match C
   2019-03-29   HME  Added GetMin and GetMax frequency
                     Updated version to 1.03
   2019-05-12   HME  Added GetMin and GetMax frequency
                     Updated version to 1.05 to match C version number
*/

/* ---------------------------- Begin test case ---------------------------- */
/* This is a test case to play with passing lists. It's called in Python
like this:

   import my_module

   testlist = [1, 2, 3, 4, 5]
   print("List before multiplying = ",testlist)
   my_module.timesTwo(testlist)
   print("List after multiplying = ",testlist)
*/

static PyObject* LDA_module_timesTwo(PyObject *self, PyObject *args)
{
  int i, numLines;
  PyObject *listObj, *numObj;
  unsigned int n;

  n = PyTuple_Size(args);
  if (1 == n) {
    /* argument 1 should be an list of integers */
    listObj = PyTuple_GetItem(args, 0);
    /* get the number of elements in the list */
    numLines = PyList_Size(listObj);
#if VERBOSE
    printf("We have %d elements\r\n", numLines);
#endif
    
    /* should raise an error here. */
    if (numLines < 0)   return NULL; /* Not a list */

    for (i=0; i<numLines; i++) {
      numObj = PyList_GetItem(listObj, i);
      n = PyLong_AsLong(PyNumber_Long(numObj));
#if VERBOSE
      printf("Element %d is %d", i, n);
#endif
      // This is the action - multiply by 2 for the test case
      n = n * 2;
#if VERBOSE
      printf(" and multiplied by 2 = %d\r\n", n);
#endif
      PyList_SetItem(listObj, i, Py_BuildValue("i", n));
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "Function expects one argument");
      return NULL;
  }
  return PyLong_FromLong(1);
}
/* ---------------------------- End test case ---------------------------- */

// A module that takes no arguments
static PyObject* LDA_module_print_hello_world(PyObject *self, PyObject *args)
{
  printf("LDA sez: Hello World\r\n");
  Py_RETURN_NONE;
}

//Actual module method definition - this is the code that will be called by
//hello_module.count_to_n
static PyObject* LDA_module_count_to_n(PyObject *self, PyObject *args)
{
  int i,n;
  PyObject *temp_p;

  n = 10;  // in case we don't get any args we like
  
#if VERBOSE
  printf("I think you sent me %d args?\r\n", PyTuple_Size(args));
#endif
  for (i=0; i<PyTuple_Size(args); i++) {
    temp_p = PyTuple_GetItem(args, i);
    if (1 == PyNumber_Check(temp_p)) {
      n = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg %d is %d\r\n", i, n);
#endif
    } else
#if VERBOSE
      printf("arg %d is not a number!\r\n", i);
#else
    i = i + 0;  // we need something here to keep the processor happy.
#endif
  }
  printf("Shall we count to %d?\r\n", n);
  for (i=1; i<n+1; i++) {
    printf("%d ", i);
  }
  printf("\r\n");
  Py_RETURN_NONE;
}

/* This is the Vaunix-specific stuff. */
//void fnLDA_Init(void);
// A module that takes no arguments
static PyObject* LDA_module_fnLDA_Init(PyObject *self, PyObject *args)
{
  fnLDA_Init();
  Py_RETURN_NONE;
}

//void fnLDA_SetTraceLevel(int tracelevel, int IOtracelevel, bool verbose);
static PyObject* LDA_module_fnLDA_SetTraceLevel(PyObject *self, PyObject *args)
{
  int n;
  int tracelevel, IOtracelevel, verbose;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (3 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      tracelevel = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetTestMode sez: arg 1 is tracelevel %d\r\n", tracelevel);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTraceLevel expects a number as the first argument.");
      return NULL;
    }

    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      IOtracelevel = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetTestMode sez: arg 2 is IOtracelevel %d\r\n", IOtracelevel);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTraceLevel expects a number as the second argument.");
      return NULL;
    }

    temp_p = PyTuple_GetItem(args, 2);
    if (1 == PyNumber_Check(temp_p)) {
      verbose = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetTestMode sez: arg 3 is verbose %d\r\n", verbose);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTraceLevel expects a number as the third argument.");
      return NULL;
    }

    fnLDA_SetTraceLevel(tracelevel, IOtracelevel, verbose);

  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTraceLevel expects three arguments.");
      return NULL;
  }
  Py_RETURN_NONE;
}

//void fnLDA_SetTestMode(bool testmode);
static PyObject* LDA_module_fnLDA_SetTestMode(PyObject *self, PyObject *args)
{
  int n;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetTestMode sez: arg 1 is devid %d\r\n", devid);
#endif
      fnLDA_SetTestMode(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTestMode expects one argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetTestMode expects one argument");
      return NULL;
  }
  Py_RETURN_NONE;
}

//LVSTATUS fnLDA_SetChannel(DEVID deviceID, int channel);
static PyObject* LDA_module_fnLDA_SetChannel(PyObject *self, PyObject *args)
{
  int n, result, channel;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetChannel sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetChannel expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      channel = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is channel %d\r\n", channel);
#endif
      result = fnLDA_SetChannel(devid, channel);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetChannel expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetChannel expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_GetNumChannels(DEVID deviceID)
static PyObject* LDA_module_fnLDA_GetNumChannels(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetNumChannels sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetNumChannels(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetNumChannels expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetNumChannels expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetNumDevices();
// A module that takes no arguments
static PyObject* LDA_module_fnLDA_GetNumDevices(PyObject *self, PyObject *args)
{
  int n;
  n = fnLDA_GetNumDevices();
  return PyLong_FromLong(n);
}

//int fnLDA_GetDevInfo(DEVID *ActiveDevices)
static PyObject* LDA_module_fnLDA_GetDevInfo(PyObject *self, PyObject *args)
{
  int i, n, numElements, result;
  PyObject *listObj, *numObj;
  unsigned int cActiveDevices[MAXDEVICES];

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) {
    /* argument 1 should be an list of integers */
    listObj = PyTuple_GetItem(args, 0);
    /* get the number of lines passed to us */
    numElements = PyList_Size(listObj);

    /* should raise an error here. */
    if (numElements < 0)   return NULL; /* Not a list */
    if (numElements > MAXDEVICES) numElements = MAXDEVICES; /* Limit the number of devices to match the MAXDEVICES */
#if VERBOSE
    printf("The list has %d elements\r\n", numElements);
#endif
    
    for (i=0; i<numElements; i++) {
      numObj = PyList_GetItem(listObj, i);
      cActiveDevices[i] = PyLong_AsUnsignedLong(PyNumber_Long(numObj));
#if VERBOSE
      printf("Before, element %d is %d\r\n", i, cActiveDevices[i]);
#endif
    }
    result = fnLDA_GetDevInfo(cActiveDevices);
    
    for (i=0; i<numElements; i++) {
      PyList_SetItem(listObj, i, Py_BuildValue("i", cActiveDevices[i]));
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDevInfo expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetModelName(DEVID deviceID, char *ModelName);
static PyObject* LDA_module_fnLDA_GetModelName(PyObject *self, PyObject *args)
{
  int n;
  unsigned int devid;
  PyObject *temp_p;
  char ModelName[64];

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetModelName sez: arg 1  is devid %d\r\n", devid);
#endif
      //result = fnLDA_GetModelName(i, ModelName);
      fnLDA_GetModelName(devid, ModelName);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetModelName expects one argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetModelName expects one argument");
      return NULL;
  }
  return PyBytes_FromString(ModelName);
}

//int fnLDA_InitDevice(DEVID deviceID);
static PyObject* LDA_module_fnLDA_InitDevice(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("InitDevice sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_InitDevice(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_InitDevice expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_InitDevice expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_CloseDevice(DEVID deviceID);
static PyObject* LDA_module_fnLDA_CloseDevice(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("CloseDevice sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_CloseDevice(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_CloseDevice expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_CloseDevice expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetSerialNumber(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetSerialNumber(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetSerialNumber sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetSerialNumber(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetSerialNumber expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetSerialNumber expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetLibVersion();
// A module that takes no arguments
static PyObject* LDA_module_fnLDA_GetLibVersion(PyObject *self, PyObject *args)
{
  int n;
  n = fnLDA_GetLibVersion();
  return PyLong_FromLong(n);
}

//int fnLDA_GetDeviceStatus(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetDeviceStatus(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetDeviceStatus sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetDeviceStatus(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDeviceStatus expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDeviceStatus expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetWorkingFrequency(DEVID deviceID, int frequency);
static PyObject* LDA_module_fnLDA_SetWorkingFrequency(PyObject *self, PyObject *args)
{
  int n, result, freq;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetWorkingFrequency sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetWorkingFrequency expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      freq = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is freq %d\r\n", freq);
#endif
      result = fnLDA_SetWorkingFrequency(devid, freq);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetWorkingFrequency expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetWorkingFrequency expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetAttenuation(DEVID deviceID, int attenuation);
static PyObject* LDA_module_fnLDA_SetAttenuation(PyObject *self, PyObject *args)
{
  int n, result, attenuation;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetAttenuation sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuation sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuation expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      attenuation = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuation sez: arg 2 is %d\r\n", attenuation);
#endif
      result = fnLDA_SetAttenuation(devid, attenuation);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuation expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuation expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetAttenuationQ(DEVID deviceID, int attenuation, int channel);
static PyObject* LDA_module_fnLDA_SetAttenuationQ(PyObject *self, PyObject *args)
{
  int n, result, attenuation, channel;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetAttenuationQ sez: I think you sent me %d args?\r\n", n);
#endif
  if (3 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationQ sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationQ expects three integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      attenuation = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationQ sez: arg 2 is %d\r\n", attenuation);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationQ expects three integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 2);
    if (1 == PyNumber_Check(temp_p)) {
      channel = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationQ sez: arg 3 is channel %d\r\n", channel);
#endif
      result = fnLDA_SetAttenuationQ(devid, attenuation, channel);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationQ expects three integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuation expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetRampStart(DEVID deviceID, int rampstart);
static PyObject* LDA_module_fnLDA_SetRampStart(PyObject *self, PyObject *args)
{
  int n, result, rampstart;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetRampStart sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampStart expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      rampstart = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is atten %d\r\n", rampstart);
#endif
      result = fnLDA_SetRampStart(devid, rampstart);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampStart expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampStart expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetRampEnd(DEVID deviceID, int rampstop);
static PyObject* LDA_module_fnLDA_SetRampEnd(PyObject *self, PyObject *args)
{
  int n, result, rampstop;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetRampEnd sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampEnd expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      rampstop = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is rampstop %d\r\n", rampstop);
#endif
      result = fnLDA_SetRampEnd(devid, rampstop);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampEnd expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampEnd expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetDwellTime(DEVID deviceID, int dwelltime);
static PyObject* LDA_module_fnLDA_SetDwellTime(PyObject *self, PyObject *args)
{
  int n, result, dwelltime;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetDwellTime sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTime expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      dwelltime = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is dwelltime %d\r\n", dwelltime);
#endif
      result = fnLDA_SetDwellTime(devid, dwelltime);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTime expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTime expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetDwellTimeTwo(DEVID deviceID, int dwelltime2);
static PyObject* LDA_module_fnLDA_SetDwellTimeTwo(PyObject *self, PyObject *args)
{
  int n, result, dwelltime2;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetDwellTimeTwo sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTimeTwo expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      dwelltime2 = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is dwelltime2 %d\r\n", dwelltime2);
#endif
      result = fnLDA_SetDwellTimeTwo(devid, dwelltime2);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTimeTwo expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetDwellTimeTwo expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetIdleTime(DEVID deviceID, int idletime);
static PyObject* LDA_module_fnLDA_SetIdleTime(PyObject *self, PyObject *args)
{
  int n, result, idletime;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetIdleTime sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetIdleTime expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      idletime = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is idle %d\r\n", idletime);
#endif
      result = fnLDA_SetIdleTime(devid, idletime);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetIdleTime expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetIdleTime expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetHoldTime(DEVID deviceID, int holdtime);
static PyObject* LDA_module_fnLDA_SetHoldTime(PyObject *self, PyObject *args)
{
  int n, result, holdtime;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetHoldTime sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetHoldTime expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      holdtime = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is hold %d\r\n", holdtime);
#endif
      result = fnLDA_SetHoldTime(devid, holdtime);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetHoldTime expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetHoldTime expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetProfileElement(DEVID deviceID, int index, int attenuation);
static PyObject* LDA_module_fnLDA_SetProfileElement(PyObject *self, PyObject *args)
{
  int n, result, index, attenuation;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetProfileElement sez: I think you sent me %d args?\r\n", n);
#endif
  if (3 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileElement sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileElement expects three integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      index = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileElement sez: arg 2 is index %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileElement expects three integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 2);
    if (1 == PyNumber_Check(temp_p)) {
      attenuation = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileElement sez: arg 3 is %d\r\n", attenuation);
#endif
      result = fnLDA_SetProfileElement(devid, index, attenuation);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileElement expects three integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileElement expects three arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetProfileCount(DEVID deviceID, int profilecount);
static PyObject* LDA_module_fnLDA_SetProfileCount(PyObject *self, PyObject *args)
{
  int n, result, profilecount;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetProfileCount sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileCount sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileCount expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      profilecount = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileCount sez: arg 2 is %d\r\n", profilecount);
#endif
      result = fnLDA_SetProfileCount(devid, profilecount);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileCount expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileCount expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetProfileIdleTime(DEVID deviceID, int idletime);
static PyObject* LDA_module_fnLDA_SetProfileIdleTime(PyObject *self, PyObject *args)
{
  int n, result, idletime;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetProfileIdleTime sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileIdleTime sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileIdleTime expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      idletime = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileIdleTime sez: arg 2 is %d\r\n", idletime);
#endif
      result = fnLDA_SetProfileIdleTime(devid, idletime);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileIdleTime expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileIdleTime expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetProfileDwellTime(DEVID deviceID, int dwelltime);
static PyObject* LDA_module_fnLDA_SetProfileDwellTime(PyObject *self, PyObject *args)
{
  int n, result, dwelltime;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetProfileDwellTime sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileDwellTime sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileDwellTime expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      dwelltime = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetProfileDwellTime sez: arg 2 is %d\r\n", dwelltime);
#endif
      result = fnLDA_SetProfileDwellTime(devid, dwelltime);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileDwellTime expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetProfileDwellTime expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_StartProfile(DEVID deviceID, int mode);
static PyObject* LDA_module_fnLDA_StartProfile(PyObject *self, PyObject *args)
{
  int n, result, mode;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("StartProfile sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("StartProfile sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartProfile expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      mode = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("StartProfile sez: arg 2 is %d\r\n", mode);
#endif
      result = fnLDA_StartProfile(devid, mode);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartProfile expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartProfile expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetAttenuationStep(DEVID deviceID, int attenuationstep);
static PyObject* LDA_module_fnLDA_SetAttenuationStep(PyObject *self, PyObject *args)
{
  int n, result, attenuationstep;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetAttenuationStep sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationStep sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStep expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      attenuationstep = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationStep sez: arg 2 is %d\r\n", attenuationstep);
#endif
      result = fnLDA_SetAttenuationStep(devid, attenuationstep);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStep expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStep expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetAttenuationStepTwo(DEVID deviceID, int attenuationstep2);
static PyObject* LDA_module_fnLDA_SetAttenuationStepTwo(PyObject *self, PyObject *args)
{
  int n, result, attenuationstep2;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("SetAttenuationStepTwo sez: I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationStepTwo sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStepTwo expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      attenuationstep2 = PyLong_AsLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetAttenuationStepTwo sez: arg 2 is %d\r\n", attenuationstep2);
#endif
      result = fnLDA_SetAttenuationStepTwo(devid, attenuationstep2);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStepTwo expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetAttenuationStepTwo expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetRFOn(DEVID deviceID, bool on);
static PyObject* LDA_module_fnLDA_SetRFOn(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  bool onoff;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetRFOn sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRFOn expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      onoff = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is %d\r\n", onoff);
#endif
      result = fnLDA_SetRFOn(devid, onoff);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRFOn expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRFOn expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetRampDirection(DEVID deviceID, bool up);
static PyObject* LDA_module_fnLDA_SetRampDirection(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  bool up;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetRampDirection sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampDirection expects an integer and a boolean as arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      up = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is %d\r\n", up);
#endif
      result = fnLDA_SetRampDirection(devid, up);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampDirection expects an integer and a boolean as arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampDirection expects an integer and a boolean as arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SetRampMode(DEVID deviceID, bool on);
static PyObject* LDA_module_fnLDA_SetRampMode(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  bool onoff;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SetRampMode sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampMode expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      onoff = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is %d\r\n", onoff);
#endif
      result = fnLDA_SetRampMode(devid, onoff);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampMode expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SetRampMode expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_StartRamp(DEVID deviceID, bool go);
static PyObject* LDA_module_fnLDA_StartRamp(PyObject *self, PyObject *args)
{
  int n, result, go;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("StartRamp sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartRamp expects two integer arguments");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      go = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("arg 2 is %d\r\n", go);
#endif
      result = fnLDA_StartRamp(devid, go);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartRamp expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_StartRamp expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//LVSTATUS fnLDA_SaveSettings(DEVID deviceID);
static PyObject* LDA_module_fnLDA_SaveSettings(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("SaveSettings sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_SaveSettings(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SaveSettings expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_SaveSettings expects two arguments");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetAttenuation(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetAttenuation(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetAttenuation sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetAttenuation(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuation expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuation expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetWorkingFrequency(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetWorkingFrequency(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetWorkingFrequency sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetWorkingFrequency(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetWorkingFrequency expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetWorkingFrequency expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetMinWorkingFrequency(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetMinWorkingFrequency(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetMinWorkingFrequency sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetMinWorkingFrequency(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinWorkingFrequency expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinWorkingFrequency expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetMaxWorkingFrequency(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetMaxWorkingFrequency(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetMaxWorkingFrequency sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetMaxWorkingFrequency(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMaxWorkingFrequency expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMaxWorkingFrequency expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetRampStart(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetRampStart(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetRampStart sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetRampStart(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetRampStart expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetRampStart expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetRampEnd(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetRampEnd(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetRampEnd sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetRampEnd(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetEndRampEnd expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetEndRampEnd expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetDwellTime(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetDwellTime(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetDwellTime sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetDwellTime(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDwellTime expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDwellTime expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetDwellTimeTwo(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetDwellTimeTwo(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetDwellTimeTwo sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetDwellTimeTwo(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDwellTimeTwo expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDwellTimeTwo expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetIdleTime(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetIdleTime(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetIdleTime sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetIdleTime(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetIdleTime expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetIdleTime expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetHoldTime(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetHoldTime(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetHoldTime sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetHoldTime(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetHoldTime expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetHoldTime expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetRF_On(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetRF_On(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetRF_On sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetRF_On(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetRF_On expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetRF_On expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetAttenuationStep(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetAttenuationStep(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetAttenuationStep sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetAttenuationStep(devid);
#if VERBOSE
      printf("GetAttenuationStep returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuationStep expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuationStep expects one argument");
      return NULL;
  }
#if VERBOSE
  printf("I'm going to return %#018x as an attenuation step size\r\n", result);
#endif
  return PyLong_FromLong(result);
}

//int fnLDA_GetAttenuationStepTwo(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetAttenuationStepTwo(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetAttenuationStepTwo sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetAttenuationStepTwo(devid);
#if VERBOSE
      printf("GetAttenuationStepTwo returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuationStepTwo expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetAttenuationStepTwo expects one argument");
      return NULL;
  }
#if VERBOSE
  printf("I'm going to return %#018x as an attenuation step two size\r\n", result);
#endif
  return PyLong_FromLong(result);
}

//int fnLDA_GetProfileElement(DEVID deviceID, int index);
static PyObject* LDA_module_fnLDA_GetProfileElement(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid, index;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (2 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetProfileElement sez: arg 1 is devid %d\r\n", devid);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileElement expects one integer argument");
      return NULL;
    }
    temp_p = PyTuple_GetItem(args, 1);
    if (1 == PyNumber_Check(temp_p)) {
      index = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetProfileElement sez: arg 2 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetProfileElement(devid, index);
#if VERBOSE
      printf("GetProfileELement returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileElement expects two integer arguments");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileElement expects two arguments");
      return NULL;
  }
#if VERBOSE
  printf("I'm going to return %#018x as an attenuation step two size\r\n", result);
#endif
  return PyLong_FromLong(result);
}

//int fnLDA_GetProfileCount(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetProfileCount(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetProfileCount sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetProfileCount(devid);
#if VERBOSE
      printf("GetProfileCount returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileCount expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileCount expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetProfileDwellTime(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetProfileDwellTime(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetProfileDwellTime sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetProfileDwellTime(devid);
#if VERBOSE
      printf("GetProfileDwellTime returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileDwellTime expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileDwellTime expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetProfileIdleTime(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetProfileIdleTime(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetIdleTime sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetIdleTime(devid);
#if VERBOSE
      printf("GetIdleTime returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetIdleTime expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetIdleTime expects expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetProfileIndex(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetProfileIndex(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetProfileIndex sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetProfileIndex(devid);
#if VERBOSE
      printf("GetProfileIndex returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileIndex expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetProfileIndex expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetMinAttenStep(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetMinAttenStep(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetMinAttenStep sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetMinAttenStep(devid);
#if VERBOSE
      printf("GetMinAttenStep returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinAttenStep expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinAttenStep expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetFeatures(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetFeatures(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetFeatures sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetFeatures(devid);
#if VERBOSE
      printf("GetFeatures returned %d which should be %f\r\n", result, (float)result/20.0);
#endif
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetFeatures expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetFeatures expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetMaxAttenuation(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetMaxAttenuation(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetMaxAttenuation sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetMaxAttenuation(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMaxAttenuation( expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMaxAttenuation( expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetMinAttenuation(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetMinAttenuation(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetMinAttenuation sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetMinAttenuation(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinAttenuation expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetMinAttenuation expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//int fnLDA_GetDevResolution(DEVID deviceID);
static PyObject* LDA_module_fnLDA_GetDevResolution(PyObject *self, PyObject *args)
{
  int n, result;
  unsigned int devid;
  PyObject *temp_p;

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      devid = PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("GetDevResolution sez: arg 1 is devid %d\r\n", devid);
#endif
      result = fnLDA_GetDevResolution(devid);
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDevResolution expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_GetDevResolution expects one argument");
      return NULL;
  }
  return PyLong_FromLong(result);
}

//char* fnLDA_perror(LVSTATUS status);
static PyObject* LDA_module_fnLDA_perror(PyObject *self, PyObject *args)
{
  unsigned int i, n;
  PyObject *temp_p;
  char errorstring[64];

  n = PyTuple_Size(args);
#if VERBOSE
  printf("I think you sent me %d args?\r\n", n);
#endif
  if (1 == n) { 
    temp_p = PyTuple_GetItem(args, 0);
    if (1 == PyNumber_Check(temp_p)) {
      i = 0xFFFFFFFF & PyLong_AsUnsignedLong(PyNumber_Long(temp_p));
#if VERBOSE
      printf("perror sez: arg 1 is %x\r\n", i);
#endif
      sprintf(errorstring,"%s",fnLDA_perror(i));
    } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_fnLDA_perror expects one integer argument");
      return NULL;
    }
  } else {
      PyErr_SetString(PyExc_ValueError, "LDA_module.fnLDA_fnLDA_perror expects one argument");
      return NULL;
  }
  return PyBytes_FromString(errorstring);
}

//char* fnLDA_LibVersion(void);
static PyObject* LDA_module_fnLDA_LibVersion(PyObject *self, PyObject *args)
{
  char errorstring[64];

  sprintf(errorstring,"%s",fnLDA_LibVersion());
  return PyBytes_FromString(errorstring);
}

static PyObject* LDA_module_WrapperVersion(PyObject *self, PyObject *args)
{
  return PyBytes_FromString(WRAPPERVERSION);
}

//Method definition object for this extension, these arguments mean:
//ml_name: The name of the method
//ml_meth: Function pointer to the method implementation
//ml_flags: Flags indicating special features of this method, such as
//          accepting arguments, accepting keyword arguments, being a
//          class method, or being a static method of a class.
//ml_doc:  Contents of this method's docstring
static PyMethodDef LDA_module_methods[] = { 
    {   
        "print_hello_world",
        LDA_module_print_hello_world,
        METH_NOARGS,
        "Print 'hello world' from a method defined in a C extension."
    },  
    {   
        "count_to_n",
        LDA_module_count_to_n,
        METH_VARARGS,
        "Count to some number in a C extension."
    },  
    {   
        "timesTwo",
        LDA_module_timesTwo,
        METH_VARARGS,
        "Multiplies each element in a list by 2"
    },  
    {   
        "fnLDA_Init",
        LDA_module_fnLDA_Init,
        METH_NOARGS,
        "Set up the LDA device"
    },  
    {   
        "fnLDA_SetTraceLevel",
        LDA_module_fnLDA_SetTraceLevel,
        METH_VARARGS,
        "Set trace level if desired"
    },  
    {   
        "fnLDA_SetTestMode",
        LDA_module_fnLDA_SetTestMode,
        METH_VARARGS,
        "Set test mode if desired"
    },  
    {   
        "fnLDA_GetNumDevices",
        LDA_module_fnLDA_GetNumDevices,
        METH_NOARGS,
        "Return the number of LDA devices"
    },  
    {   
        "fnLDA_GetNumChannels",
        LDA_module_fnLDA_GetNumChannels,
        METH_VARARGS,
        "Return the number channels on a specific LDA device"
    },  
    {   
        "fnLDA_SetChannel",
        LDA_module_fnLDA_SetChannel,
        METH_VARARGS,
        "Set the working channel on a specific LDA device"
    },  
    {   
        "fnLDA_GetDevInfo",
        LDA_module_fnLDA_GetDevInfo,
        METH_VARARGS,
        "Returns a list of active devices"
    },  
    {   
        "fnLDA_GetModelName",
        LDA_module_fnLDA_GetModelName,
        METH_VARARGS,
        "Returns the name of an LDA model"
    },  
    {   
        "fnLDA_InitDevice",
        LDA_module_fnLDA_InitDevice,
        METH_VARARGS,
        "Initializes an LDA device"
    },  
    {   
        "fnLDA_CloseDevice",
        LDA_module_fnLDA_CloseDevice,
        METH_VARARGS,
        "Closes an LDA device"
    },  
    {   
        "fnLDA_GetSerialNumber",
        LDA_module_fnLDA_GetSerialNumber,
        METH_VARARGS,
        "Returns the serial of an LDA device"
    },  
    {   
        "fnLDA_GetLibVersion",
        LDA_module_fnLDA_GetLibVersion,
        METH_VARARGS,
        "Returns the LDAhid library version number"
    },  
    {   
        "fnLDA_GetDeviceStatus",
        LDA_module_fnLDA_GetDeviceStatus,
        METH_VARARGS,
        "Returns the status of an LDA device"
    },  
    {   
        "fnLDA_SetWorkingFrequency",
        LDA_module_fnLDA_SetWorkingFrequency,
        METH_VARARGS,
        "Sets the working frequency on an LDA device"
    },
    {   
        "fnLDA_SetAttenuation",
        LDA_module_fnLDA_SetAttenuation,
        METH_VARARGS,
        "Sets the attenuation level on an LDA device"
    },  
    {   
        "fnLDA_SetAttenuationQ",
        LDA_module_fnLDA_SetAttenuationQ,
        METH_VARARGS,
        "Sets the attenuation level on an multi-channel LDA device"
    },  
    {   
        "fnLDA_SetRampStart",
        LDA_module_fnLDA_SetRampStart,
        METH_VARARGS,
        "Sets the starting attenuation for a ramo on an LDA device"
    },  
    {   
        "fnLDA_SetRampEnd",
        LDA_module_fnLDA_SetRampEnd,
        METH_VARARGS,
        "Sets the ending attenuation for a ramp on an LDA device"
    },
    {   
        "fnLDA_SetAttenuationStep",
        LDA_module_fnLDA_SetAttenuationStep,
        METH_VARARGS,
        "Sets the first phase of the attenuation step for a ramp on an LDA device"
    },   
    {   
        "fnLDA_SetAttenuationStepTwo",
        LDA_module_fnLDA_SetAttenuationStepTwo,
        METH_VARARGS,
        "Sets the second phase of the attenuation step for a ramp on an LDA device"
    },   
    {   
        "fnLDA_GetProfileElement",
        LDA_module_fnLDA_GetProfileElement,
        METH_VARARGS,
        "Returns the value of a specific profile element"
    },   
    {   
        "fnLDA_GetProfileCount",
        LDA_module_fnLDA_GetProfileCount,
        METH_VARARGS,
        "Returns the number of elements in an LDA profile"
    },   
    {   
        "fnLDA_GetProfileDwellTime",
        LDA_module_fnLDA_GetProfileDwellTime,
        METH_VARARGS,
        "Returns the dwell time for an LDA profile"
    },   
    {   
        "fnLDA_GetProfileIdleTime",
        LDA_module_fnLDA_GetProfileIdleTime,
        METH_VARARGS,
        "Returns the idle time from an LDA device profile"
    },   
    {   
        "fnLDA_GetProfileIndex",
        LDA_module_fnLDA_GetProfileIndex,
        METH_VARARGS,
        "Returns the index from an LDA device profile"
    },   
    {   
        "fnLDA_GetMinAttenStep",
        LDA_module_fnLDA_GetMinAttenStep,
        METH_VARARGS,
        "Returns the minimum attenuation step for an LDA device"
    },   
    {   
        "fnLDA_GetFeatures",
        LDA_module_fnLDA_GetFeatures,
        METH_VARARGS,
        "Returns the available features for an LDA device"
    },   
    {   
        "fnLDA_SetDwellTime",
        LDA_module_fnLDA_SetDwellTime,
        METH_VARARGS,
        "Sets the first phase time for each attenuation ramp step on an LDA device"
    },  
    {   
        "fnLDA_SetDwellTimeTwo",
        LDA_module_fnLDA_SetDwellTimeTwo,
        METH_VARARGS,
        "Sets the second phase time for each attenuation ramp step on an LDA device"
    },  
    {   
        "fnLDA_SetIdleTime",
        LDA_module_fnLDA_SetIdleTime,
        METH_VARARGS,
        "Sets the time between each repeated attenuation ramp on an LDA device"
    },  
    {   
        "fnLDA_SetProfileElement",
        LDA_module_fnLDA_SetProfileElement,
        METH_VARARGS,
        "Sets one element of a profile for an LDA device"
    },  
    {   
        "fnLDA_SetProfileCount",
        LDA_module_fnLDA_SetProfileCount,
        METH_VARARGS,
        "Sets the number of elements on a profile for an LDA device"
    },  
    {   
        "fnLDA_SetHoldTime",
        LDA_module_fnLDA_SetHoldTime,
        METH_VARARGS,
        "Sets the hold time for the attenuation ramp on an LDA device"
    },  
    {   
        "fnLDA_SetProfileElement",
        LDA_module_fnLDA_SetProfileElement,
        METH_VARARGS,
        "Sets a element value for a profile on an LDA device"
    },  
    {   
        "fnLDA_SetProfileCount",
        LDA_module_fnLDA_SetProfileCount,
        METH_VARARGS,
        "Sets the number of elements in a profile for an LDA device"
    },  
    {   
        "fnLDA_SetProfileIdleTime",
        LDA_module_fnLDA_SetProfileIdleTime,
        METH_VARARGS,
        "Sets the time between elements for a profile on an LDA device"
    },  
    {   
        "fnLDA_SetProfileDwellTime",
        LDA_module_fnLDA_SetProfileDwellTime,
        METH_VARARGS,
        "Sets the dwell time for elements for a profile on an LDA device"
    },  
    {   
        "fnLDA_StartProfile",
        LDA_module_fnLDA_StartProfile,
        METH_VARARGS,
        "Begin a profile on an LDA device"
    },  
    {   
        "fnLDA_SetRFOn",
        LDA_module_fnLDA_SetRFOn,
        METH_VARARGS,
        "Enables the output on an LDA device"
    },  
    {   
        "fnLDA_SetRampDirection",
        LDA_module_fnLDA_SetRampDirection,
        METH_VARARGS,
        "Sets the LDA ramp direction"
    },  
    {   
        "fnLDA_SetRampMode",
        LDA_module_fnLDA_SetRampMode,
        METH_VARARGS,
        "Sets the LDA attenuation ramp mode"
    },   
    {   
        "fnLDA_StartRamp",
        LDA_module_fnLDA_StartRamp,
        METH_VARARGS,
        "Starts the LDA attenuation ramp"
    },  
    {   
        "fnLDA_SaveSettings",
        LDA_module_fnLDA_SaveSettings,
        METH_VARARGS,
        "Saves the LDA settings"
    },  
    {   
        "fnLDA_GetWorkingFrequency",
        LDA_module_fnLDA_GetWorkingFrequency,
        METH_VARARGS,
        "Returns the current LDA working frequency"
    },
    {   
        "fnLDA_GetMinWorkingFrequency",
        LDA_module_fnLDA_GetMinWorkingFrequency,
        METH_VARARGS,
        "Returns the minimum LDA working frequency"
    },
    {   
        "fnLDA_GetMaxWorkingFrequency",
        LDA_module_fnLDA_GetMaxWorkingFrequency,
        METH_VARARGS,
        "Returns the maximum LDA working frequency"
    },
    {   
        "fnLDA_GetAttenuation",
        LDA_module_fnLDA_GetAttenuation,
        METH_VARARGS,
        "Returns the current LDA attenuation"
    }, 
    {   
        "fnLDA_GetRampStart",
        LDA_module_fnLDA_GetRampStart,
        METH_VARARGS,
        "Returns the current LDA ramp start attenuation"
    },  
    {   
        "fnLDA_GetRampEnd",
        LDA_module_fnLDA_GetRampEnd,
        METH_VARARGS,
        "Returns the current LDA ramp end attenuation"
    },
    {   
        "fnLDA_GetAttenuationStep",
        LDA_module_fnLDA_GetAttenuationStep,
        METH_VARARGS,
        "Returns the current LDA attenuation step size for ramps"
    },   
    {   
        "fnLDA_GetAttenuationStepTwo",
        LDA_module_fnLDA_GetAttenuationStepTwo,
        METH_VARARGS,
        "Returns the current LDA attenuation step2 size for ramps"
    },   
    {   
        "fnLDA_GetDwellTime",
        LDA_module_fnLDA_GetDwellTime,
        METH_VARARGS,
        "Returns the current LDA dwell time"
    },
    {   
        "fnLDA_GetDwellTimeTwo",
        LDA_module_fnLDA_GetDwellTimeTwo,
        METH_VARARGS,
        "Returns the current LDA dwelltime two"
    },
    {   
        "fnLDA_GetIdleTime",
        LDA_module_fnLDA_GetIdleTime,
        METH_VARARGS,
        "Returns the current LDA idle time"
    },   
    {   
        "fnLDA_GetHoldTime",
        LDA_module_fnLDA_GetHoldTime,
        METH_VARARGS,
        "Returns the current LDA hold time"
    },   
    {   
        "fnLDA_GetRF_On",
        LDA_module_fnLDA_GetRF_On,
        METH_VARARGS,
        "Returns the current on/off RF state"
    },    
    {   
        "fnLDA_GetMaxAttenuation",
        LDA_module_fnLDA_GetMaxAttenuation,
        METH_VARARGS,
        "Returns the LDA device maximum attenuation"
    },  
    {   
        "fnLDA_GetMinAttenuation",
        LDA_module_fnLDA_GetMinAttenuation,
        METH_VARARGS,
        "Returns the LDA device minimum attenuation"
    }, 
    {   
        "fnLDA_GetDevResolution",
        LDA_module_fnLDA_GetDevResolution,
        METH_VARARGS,
        "Returns the LDA device minimum hardware attenuation step"
    },  
    {   
        "fnLDA_perror",
        LDA_module_fnLDA_perror,
        METH_VARARGS,
        "Converts an LDA library error to a string"
    },  
    {   
        "fnLDA_LibVersion",
        LDA_module_fnLDA_LibVersion,
        METH_NOARGS,
        "Returns the LDA library version"
    },  
    {   
        "WrapperVersion",
        LDA_module_WrapperVersion,
        METH_NOARGS,
        "Returns the LDA library wrapper version"
    },  
    {NULL, NULL, 0, NULL}
};

//Module definition
//The arguments of this structure tell Python what to call your extension,
//what it's methods are and where to look for it's method definitions
static struct PyModuleDef LDA_module_definition = { 
    PyModuleDef_HEAD_INIT,
    "LDA_module",
    "A Python module for managing the Vaunix LDA series synthesizers.",
    -1, 
    LDA_module_methods
};

//Module initialization
//Python calls this function when importing your extension. It is important
//that this function is named PyInit_[[your_module_name]] exactly, and matches
//the name keyword argument in setup.py's setup() call.
PyMODINIT_FUNC PyInit_LDA_module(void)
{
    Py_Initialize();

    return PyModule_Create(&LDA_module_definition);
}

