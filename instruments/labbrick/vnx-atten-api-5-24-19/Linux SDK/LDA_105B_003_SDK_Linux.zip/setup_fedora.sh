#!/bin/bash
echo "This is a test version for 64-bit Fedora!!!"
if [ -f "LDA_setup_date.txt" ]
then
    rundate=$(<LDA_setup_date.txt)
    echo "I think you've already set up the Vaunix LDA support"
    echo "for Python3. I think so because I see a file called"
    echo "'LDA_setup_date.txt' that says this was run"
    echo "on $rundate. If you want to run it"
    echo "again, that's fine. Just delete 'LDA_setup_date.txt'"
    echo "and we should be good to go."
else
    # Let's remember that we've already done this
    date > LDA_setup_date.txt
    # EMACS is a cool editor. Uncomment this to get it
    #sudo dnf install emacs
    # We probably already have Python 3, but we'll make sure
    #sudo dnf install python3
    #sudo dnf upgrade python3
    # And get the dev tools for it
    sudo dnf install python3-devel
    # This is the USB library if it isn't already installed
    sudo dnf install libusbx
    sudo dnf install libusbx-devel
    # This resolves missing redhat support
    sudo dnf install redhat-rpm-config
    # Build the LDA library and the C test program. We need the .o file
    #   to install the Python extension
    sudo make
    # Install the LDA Python extension and upgrade it if necessary
    sudo pip3 install . --upgrade
    #
    #
    # If we want to just run the test program now we can.
    #   Because the USB access is priveleged, you have to use 'sudo'
    #   to run Python and access the USB library.
    sudo python3 LDA_test.py
    #
    # Alternatively you can play with the test program interactively
    #   in IDLE. Once it starts, use File->Open to open 'LDA_test.py'
    #sudo idle3
    echo "Don't forget to use 'sudo' when you run Python."
    echo "'sudo python3 LDA_test.py' runs the sample test program."
    echo "'sudo idle3' brings up the interactive IDLE environment."
fi
