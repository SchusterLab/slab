This VNX_atten.dll is compiled with the __stdcall calling convention so it can be used with Microsoft's Visual Basic for Applications ("VBA")

The Excel worksheet has a test macro which demonstrates the operation of the dll with Excel. To run the example make sure that the dll is located where Excel
can find it. For testing the dll was copied into the Excel program directory. Other locations are acceptable if the system path is updated accordingly.

5-6-2016