﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace LabBrickAttTest
{
    public class LabBrickWrapper
    {
        // The dll imports
        [DllImport("./VNX_atten.dll", EntryPoint = "fnLDA_GetNumDevices")]
        static extern int fnLDA_GetNumDevices();

        [DllImport("./VNX_atten.dll", EntryPoint = "fnLDA_SetTestMode")]
        static extern void fnLDA_SetTestMode(bool mode);

        // ...

        public int GenNumberOfDevices()
        {
            return fnLDA_GetNumDevices();
        }

        public void SetTetsMode(bool mode)
        {
            fnLDA_SetTestMode(mode);
        }
    }
}
