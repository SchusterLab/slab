﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LabBrickAttTest
{
    public partial class Form1 : Form
    {
        private int m_NumberOfDevices = 0;
        LabBrickWrapper m_LabBrick = null;

        public Form1()
        {
            InitializeComponent();

            m_LabBrick = new LabBrickWrapper();
            m_NumberOfDevices = m_LabBrick.GenNumberOfDevices();    // EntryPointNotFoundException
        }
    }
}
