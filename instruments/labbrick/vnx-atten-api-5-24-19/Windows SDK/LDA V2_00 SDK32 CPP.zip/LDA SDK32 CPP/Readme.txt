This release of the Win32 version of the Vaunix Lab Brick Attenuator DLL contains a test program which can
be built using Visual Studio 2008.

The DLL supports the LDA-102, LDA-602, LDA-302P-H, LDA-302P-1, LDA-302P-2, LDA-102E and LDA-602E attenuators.

The DLL has C++ style naming, and uses the standard Windows C++ calling sequence.

Note that although all attenuation values are specified in the units of .25db, the minimum attenuation increment is determined by the Lab Brick
hardware. The LDA-102, LDA-602, and LDA-302P-H attenuators have a minimum attenuation increment of .5db. The LDA-302P-1 has a minimum attenuation
increment of 1db, and the LDA-302P-2 has a minimum attenuation increment of 2db. The Lab Brick Attenuator DLL will round down any attenuation value
that has a higher resolution than the hardware supports. Thus, for example, calling the fnLDA_SetAttenuation function with an attenuation value
of 42 will result in 10.5db of attenuation on an LDA-102, and 10db of attenuation on an LDA-302P-1.

Released 4/23/2014