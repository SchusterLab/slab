import ctypes
from ctypes import *
vnx = cdll.LoadLibrary("/usr/local/lib/libLDA_API.dylib")
vnx.fnLDA_SetTestMode(0)
vnx.fnLDA_SetTraceLevel(0,0,0)
print(vnx.fnLDA_GetNumDevices())
DeviceIDArray = c_int * 20
Devices = DeviceIDArray()
vnx.fnLDA_GetDevInfo(Devices)
print(vnx.fnLDA_InitDevice(Devices[0]))
print(vnx.fnLDA_GetDeviceStatus(Devices[0]))
print(vnx.fnLDA_SetChannel(Devices[0], 1))
print(vnx.fnLDA_GetAttenuationHR(Devices[0]))
print(vnx.fnLDA_GetWorkingFrequency(Devices[0]))
